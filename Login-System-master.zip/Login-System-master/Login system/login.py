import backEndUtilityFuncs

def login_or_not(username, password):
    return backEndUtilityFuncs.checkIfCorrect(username, password)

